<?php
$this->RemoveEventHandler('Core', 'ContentEditPost');
?>

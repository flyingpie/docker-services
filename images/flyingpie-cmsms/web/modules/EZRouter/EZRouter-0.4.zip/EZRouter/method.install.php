<?php
$this->AddEventHandler('Core', 'ContentEditPost', true);
?>
